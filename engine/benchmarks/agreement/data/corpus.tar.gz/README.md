# Parity regression corpus (V8-parity-regression-corpus, 2026-09-27)

Opus KK. Every played-game position the three parity runs compared with Showdown, kept with the
oracle report(s) it was compared against, so an engine change is re-checked against all of them
with `lab-check` alone: about 5-10 minutes with 2 jobs instead of hours of Showdown time. The sweeps
had kept only the reports of positions that did not match (`--keep-reports mismatch`), so this
corpus re-ran the oracle once for every position, in exactly the mode its sweep compared it.

**An engine-verification sample, not a party-strength result.** A match means lab-engine's outcome
distribution equals Showdown's for that one pinned position in that roll mode; the corpus is what
these self-play games produced (feature coverage: `features.md`, V2c), not a proof for the engine.

## Contents

| set | source run (sweep rows) | engine the sweep compared with | positions | compared by |
|---|---|---|---|---|
| `ff` | `runs/parity-20260927` (`positions/`, `sweep/rows`), the 27 overflow positions replaced by `runs/parity-20260927c` (`positions-ff/`, `sweep-ff/rows`) | `5fb726f`; overflow `7a787fc` | 718 (+ 11 excluded) | full 537, extremes 154, staged fixed 7/0/15 27 (+ staged extremes 25) |
| `ff-postfix-games` | `runs/parity-20260927` (`postfix-games/`, `postfix-games-sweep/rows`): crown-cecil9 vs perish-mrada regenerated after FF's fixes | `47cbbfd` | 58 | full 47, extremes 11 |
| `v2` | `runs/parity-20260927b` (`positions/`, `sweep/rows`), the 66 overflow positions replaced by `runs/parity-20260927c` (`positions-v2/`, `positions-v2b/`, `positions-postfix/` and their `sweep-*/rows`) | `b04d9fb` (32 re-run at `b412cdf`); overflow `7a787fc`/`b9258ca` | 1,000 | full 683, extremes 251, staged fixed 7/0/15 66 (+ staged extremes 60) |
| **all** | | | **1,776** | full 1,267, extremes 416, fixed 93 (3 reports each), + staged extremes 85 = **2,047 reports** |

`sources.json` lists these sources; a later source replaces an earlier entry with the same set and
stem (the heavy-turn rows replace the overflow rows). The FF `postfix/` re-sweep is not a source (its
119 positions are copies of FF positions).

Excluded (no oracle report exists; `corpus.json` entries with `build: excluded` and the reason):
- `ff/crown-cecil9-vs-perish-mrada.random.g000.s04`-`s09` (6): their pinned turn 4 was played by
  the engine with the Perish Song vs Good as Gold bug (fixed in `47cbbfd`); the recorded outcome does
  not exist in Showdown. The regenerated games are the `ff-postfix-games` set.
- `ff/psy-cona-vs-sand-owen.nash.g000.s01`-`s05` (5): the oracle did not find the lead turn's
  recorded outcome (2,000 random walks, more than 200,000 extremes branches).

## Layout

```
sources.json                                  the sweeps the corpus is built from (build input)
corpus.json                                   index: every position (included or excluded), its
                                              source row and engine, plan, reports, sizes, team files
positions/<set>/<stem>.scenario.json.gz       the scenario: teams inlined (paths and SHA-256 in the
                                              index), start/setup traces written in
positions/<set>/<stem>.<label>.report.json.gz its oracle report(s); label full, extremes,
                                              fixed<k>-staged, extremes-staged
build/rows/<set>/<stem>.json                  build log per position (oracle attempts, seconds)
build.sh, build.log                           the build that made the corpus
features.md, features.json                    feature coverage and gaps (parity_features.py, V2c)
check-<commit>/                               a check: summary.md, summary.json, rows/, verdicts/
check.sh, check.log                           the latest check
```

Sizes (`parity_corpus.py stats`): 3,823 files (1,776 scenarios, 2,047 reports), **16.2 MB gzipped**
(16,159,658 bytes) for 712 MB of JSON (712,319,476 bytes; 44x); largest compressed file 282 KB
(`v2/dbl-kickoff-beedrillvgc-vs-kickoff-conkledonk.a.nash.g000.s06.extremes`), largest report 32.4
MB uncompressed (`v2/mech-masagon-lucario-salamence-vs-mutsu-baxcalibur.a.random.g000.s05.extremes`);
`corpus.json` 4.2 MB. Compression matters: the per-outcome canonical states and logs repeat.

## Commands

```sh
# re-check an engine build against the whole corpus (exit 0 only if every position matches)
PYTHONUTF8=1 python engine/scripts/parity_corpus.py check runs/parity-corpus-20260927 \
  --jobs 2 --check <target>/release/lab-check.exe --out runs/parity-corpus-20260927/check-<commit>
# one position, uncompressed, for lab-check / lab-turn by hand
python engine/scripts/parity_corpus.py extract runs/parity-corpus-20260927 v2/<stem> --out <dir>
python engine/scripts/parity_corpus.py stats runs/parity-corpus-20260927
# feature coverage of the corpus (V2c): features.md, features.json
PYTHONUTF8=1 python engine/scripts/parity_features.py runs/parity-corpus-20260927
# the build (resumable; LAB_ROOT for the oracle's Showdown; 2 jobs on the shared machine from now on)
LAB_ROOT=D:/pokemon-ai-lab PYTHONUTF8=1 python engine/scripts/parity_corpus.py build \
  runs/parity-corpus-20260927 --jobs 2 --timeout 3600 --resume
```

Each report was made with the command its sweep used for it: `node engine/oracle/enumerate.cjs
<scenario> --mode <full|extremes|fixed> [--roll k] [--staged] --collapse-secondaries --traces
--max-branches <cap>` with the sweep's cap (full 20,000, extremes 60,000, staged fixed 200,000
runs, staged extremes 100,000 runs). `check` decompresses each position to a temporary directory and
runs `lab-check <scenario> <report>` per report; a position with several reports matches only if all
of them do.

## Versions

- Oracle: `engine/oracle/enumerate.cjs` of `lab-engine` `37e2e40` (unchanged since JJ's `7a787fc`;
  sha256 `f66220f4...` in `corpus.json`), Showdown `vendor/pokemon-showdown`
  9e317a666d9fd250f36f494778e843141f09bdba (every report's `showdownCommit`).
- Build: 2026-09-27, `parity_corpus.py` of `465c15b`, 3 jobs on a machine shared with about five
  sessions: 8,465 s wall, 24,688 s of oracle time. 0 failures. **No report differs from its sweep
  row** in branch or outcome count (the sweeps' rows record both; `differs_from_sweep` 0).

## Result: the first full re-check since the sweeps

| engine | positions | match | mismatch | engine error | wall (2 jobs) | lab-check engine time |
|---|---|---|---|---|---|---|
| `465c15b` (lab-engine `37e2e40` + the setup-replay merge index) | 1,776 | 1,765 | 0 | 11 | 307 s | 328 s |
| **`7c6b5cb`** (+ pinned-turn Full fallback) | **1,776** | **1,776** | **0** | **0** | 582 s (heavier machine load) | 315 s |

This is the first check of all compared positions against one build since GG's optimisations, B30/V6
(Trick Room Speed), B29 (paused setup turns) and JJ's confusion-roll fix: every report of every
position matches (`check-7c6b5cb/summary.md`: full 1,267, extremes 416, fixed 93 with staged extremes
on 85; turns 1,313, replacements 463).

The 11 engine errors of the first check were one game, `v2/dbl-psy-lello-vs-psy-nihat.b.random.g000`
decisions 7-17: the engine could not replay pinned setup turn 7 ("none of 12 position(s) has the
pinned canonical state; closest differs at Arcanine hp 78 vs 75"). Arcanine was confused and hit
itself for a middle roll (78 HP; min roll 79, max 75). The game was played by `b04d9fb`, whose
`Extremes` mode still drew the confusion self-hit from all 16 rolls (`uniform(16)`, fixed in
`b9258ca`); Showdown reaches the pin through its trace, the fixed engine's `Extremes` replay cannot.
Not an engine bug: the pinned history came from the old roll mode. `7c6b5cb` makes the setup replay
look for a pinned state the reduced mode misses in the turn's exact (`Full`) distribution before it
gives up (test `engine/scenario/tests/kk_pinned_roll_fallback.rs`); all 11 then match.

`465c15b` also fixed a quadratic merge in the setup replay (`lab-scenario` `replay_setup_turns`
scanned the outcome list for every outcome; one pinned setup turn of that game has 37,686
`Extremes` outcomes): its positions took 180-294 s each in the V2 sweep (`b04d9fb`) and s05 took
144 s at `37e2e40`; now 3-5 s. Without the fix that one game would add about 40 minutes to a check.

## Limits

- The corpus is what the three runs compared: 1,776 positions of 158 self-play games (FF and V2
  matchups; the `mech-*` V2 games are single-format teams under doubles rules, a mechanical sample).
  Lead turns are not positions. Feature coverage and its gaps: `features.md`.
- 416 positions are compared in `extremes` (min/max rolls) and 93 heavy turns only with fixed rolls
  7/0/15 (+ staged extremes on 85), exact for those roll modes only.
- The reports are Showdown `9e317a6` through the oracle of `37e2e40`; if either changes semantics
  the corpus must be rebuilt (a new directory, or delete `build/rows` and `positions`). The staged
  reports trust `Battle.fromJSON` between actions as JJ's README describes.
- The pinned histories were generated by older engine builds; the check verifies each decision turn
  from the pinned state, and a setup replay that needs the `Full` fallback costs more (at most a few
  seconds here).
- Check time is dominated by decompressing 712 MB of reports and process start-up when the machine is
  busy: the engine part is about 5.5 CPU minutes.

## V12 (Opus VV, 2026-09-28): the 11 excluded FF positions

This copy of the corpus (VV worktree `runs/parity-corpus-20260927`; the directories it reads its
sources from are junctions to `D:/pokemon-ai-lab/runs`) adds one source to `sources.json`: LL's V3
re-sweep of the 11 positions (`runs/parity-20260927d/v3-failed`, rows `v3-failed-sweep/rows`).

- `ff/psy-cona-vs-sand-owen.nash.g000.s01`-`s05` (lead turn's recorded outcome not found before):
  the oracle's staged pin search finds it; **built** into the corpus (`build --resume --only`,
  `build-v12.log`: full 1, extremes 45, full 1, full 1, extremes 6 outcomes; 28 s) and compared.
- `ff/crown-cecil9-vs-perish-mrada.random.g000.s04`-`s09`: **discarded** (`sources.json`
  `discarded`, reason kept in `corpus.json` as `excluded: discarded: stale pin ...`): their pinned
  turn 4 was played with the Perish Song vs Good as Gold bug (fixed in `47cbbfd`), the outcome does
  not exist in Showdown, and the V3 staged search finds no branch either; the regenerated game is
  the `ff-postfix-games` set.

Totals now: 1,787 entries, **1,781 positions**, 2,052 reports, 6 excluded (all discarded).
Check at VV `0e0cc4d`+ (`check-v12/`, batch runner, 2 jobs, beside a cargo test run): **1,781 / 1,781
match**, 561 s wall.
