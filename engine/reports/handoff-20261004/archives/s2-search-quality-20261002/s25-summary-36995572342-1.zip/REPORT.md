# S25b search-quality pilot

References: 5/5; valid trials: True

| case | seconds | baseline available | selective available | baseline BR gap | selective BR gap |
|---|---:|---:|---:|---:|---:|
| speed-swap-full | 0.01 | 3/3 | 3/3 | -0.000000 | 0.000298 |
| speed-swap-full | 0.05 | 3/3 | 3/3 | 0.006581 | 0.000908 |
| speed-swap-full | 0.25 | 3/3 | 3/3 | 0.006581 | 0.000908 |
| speed-swap-full | 1 | 3/3 | 3/3 | 0.006581 | 0.000908 |
| speed-swap-full | 3 | 3/3 | 3/3 | 0.006581 | 0.000908 |
| half-hp-median | 0.01 | 0/3 | 3/3 | — | 7822.882870 |
| half-hp-median | 0.05 | 3/3 | 3/3 | 7821.545820 | 430.816315 |
| half-hp-median | 0.25 | 3/3 | 3/3 | 23.164024 | 9075.806554 |
| half-hp-median | 1 | 3/3 | 3/3 | 0.139290 | 9482.397197 |
| half-hp-median | 3 | 3/3 | 3/3 | 0.139290 | 9482.397197 |
| helping-hand-median | 0.01 | 3/3 | 3/3 | 10.146301 | 7.321731 |
| helping-hand-median | 0.05 | 3/3 | 3/3 | 5.996904 | 3.444405 |
| helping-hand-median | 0.25 | 3/3 | 3/3 | 0.009706 | 0.000959 |
| helping-hand-median | 1 | 3/3 | 3/3 | 0.009706 | 0.000942 |
| helping-hand-median | 3 | 3/3 | 3/3 | 0.009706 | 0.000942 |
| pivot-median | 0.01 | 3/3 | 3/3 | 7.686681 | 0.006231 |
| pivot-median | 0.05 | 3/3 | 3/3 | 0.009923 | 0.006231 |
| pivot-median | 0.25 | 3/3 | 3/3 | 0.009923 | 0.006231 |
| pivot-median | 1 | 3/3 | 3/3 | 0.009923 | 0.006231 |
| pivot-median | 3 | 3/3 | 3/3 | 0.009923 | 0.006231 |
| pivot-full | 0.01 | 3/3 | 3/3 | 7.724926 | 0.005988 |
| pivot-full | 0.05 | 3/3 | 3/3 | 0.009840 | 0.005988 |
| pivot-full | 0.25 | 3/3 | 3/3 | 0.009840 | 0.005988 |
| pivot-full | 1 | 3/3 | 3/3 | 0.009840 | 0.005988 |
| pivot-full | 3 | 3/3 | 3/3 | 0.009840 | 0.005988 |
| coaching-median | 0.1 | 0/3 | 0/3 | — | — |
| coaching-median | 0.5 | 0/3 | 3/3 | — | — |
| coaching-median | 2 | 0/3 | 3/3 | — | — |
| coaching-median | 5 | 3/3 | 3/3 | — | — |
| coaching-median | 15 | 3/3 | 3/3 | — | — |
| sand-median | 0.1 | 0/3 | 0/3 | — | — |
| sand-median | 0.5 | 0/3 | 0/3 | — | — |
| sand-median | 2 | 0/3 | 0/3 | — | — |
| sand-median | 5 | 0/3 | 3/3 | — | — |
| sand-median | 15 | 3/3 | 3/3 | — | — |

Lower reference BR gap is better; no policy is missing, not a zero gap.

- Perfect information; no hidden-state strength claim.
- Reference uses independent traversal but shared engine adapter and RM+; propagated numerical intervals are recorded.
- Full action under Sensible pruning and specified roll mode, not an unrestricted full-game certificate.
- Old search can evaluate unresolved switches at horizon and use maximin inside switches; this remains an algorithm difference.
- Work-budget curves contain completed incumbents before cost thresholds; old solver is externally time-capped, not globally transition-capped.
- CPU and peak RSS are whole-process metrics including setup and a possible final overrun; time-cutoff policy eligibility uses internal timestamps.
- Three AB/BA pairs form a pilot, not a broad speedup or playing-strength result.
