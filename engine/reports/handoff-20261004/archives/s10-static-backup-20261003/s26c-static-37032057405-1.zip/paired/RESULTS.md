# S26c speed-only benchmark

One generic x86-64 release binary; serial execution pinned to one runner CPU. Seven ABBA/BAAB blocks; three selection seeds where applicable.
Intervals describe paired block variability on this runner, not variability between machines. Every candidate matches its reference tree, entire policy, certificate and work exactly.

| Case | Variant | Baseline ms | Candidate ms | Time reduction | Complete horizon |
|---|---|---:|---:|---:|---|
| stats-w1-d2-b4-seed1 | in-place-compiler | 13.685 | 13.076 | +4.56% | False |
| stats-w1-d2-b4-seed1 | all | 13.653 | 13.003 | +5.02% | False |
| stats-w1-d2-b4-seed1 | cached | 13.655 | 13.434 | +1.52% | False |
| stats-w1-d2-b4-seed1 | all-cached | 13.675 | 12.845 | +6.05% | False |
| stats-w1-d2-b10000-seed1 | in-place-compiler | 117.985 | 102.881 | +13.10% | True |
| stats-w1-d2-b10000-seed1 | all | 117.749 | 101.385 | +13.90% | True |
| stats-w1-d2-b10000-seed1 | cached | 117.829 | 114.742 | +2.47% | True |
| stats-w1-d2-b10000-seed1 | all-cached | 117.405 | 99.737 | +14.89% | True |
| stats-w1-d2-b10000-seed7 | in-place-compiler | 116.800 | 101.497 | +13.31% | True |
| stats-w1-d2-b10000-seed7 | all | 116.773 | 100.739 | +13.70% | True |
| stats-w1-d2-b10000-seed7 | cached | 117.016 | 113.579 | +2.16% | True |
| stats-w1-d2-b10000-seed7 | all-cached | 116.320 | 98.209 | +15.82% | True |
| stats-w1-d2-b10000-seed31 | in-place-compiler | 119.334 | 104.177 | +12.95% | True |
| stats-w1-d2-b10000-seed31 | all | 119.412 | 103.243 | +13.52% | True |
| stats-w1-d2-b10000-seed31 | cached | 119.477 | 116.904 | +2.19% | True |
| stats-w1-d2-b10000-seed31 | all-cached | 119.722 | 101.399 | +15.03% | True |
| stats-w2-d2-b4-seed1 | in-place-compiler | 26.402 | 25.299 | +4.07% | False |
| stats-w2-d2-b4-seed1 | all | 26.372 | 25.151 | +4.57% | False |
| stats-w2-d2-b4-seed1 | cached | 26.342 | 25.984 | +1.49% | False |
| stats-w2-d2-b4-seed1 | all-cached | 26.296 | 24.779 | +5.71% | False |
| stats-w2-d2-b10000-seed1 | in-place-compiler | 213.294 | 189.028 | +11.38% | True |
| stats-w2-d2-b10000-seed1 | all | 213.107 | 187.416 | +12.07% | True |
| stats-w2-d2-b10000-seed1 | cached | 211.712 | 207.345 | +2.79% | True |
| stats-w2-d2-b10000-seed1 | all-cached | 213.305 | 184.244 | +13.62% | True |
| stats-w2-d2-b10000-seed7 | in-place-compiler | 219.647 | 194.209 | +11.36% | True |
| stats-w2-d2-b10000-seed7 | all | 220.328 | 192.457 | +12.22% | True |
| stats-w2-d2-b10000-seed7 | cached | 219.989 | 214.441 | +2.66% | True |
| stats-w2-d2-b10000-seed7 | all-cached | 219.772 | 189.054 | +14.09% | True |
| stats-w2-d2-b10000-seed31 | in-place-compiler | 218.998 | 194.124 | +11.44% | True |
| stats-w2-d2-b10000-seed31 | all | 218.267 | 192.328 | +11.93% | True |
| stats-w2-d2-b10000-seed31 | cached | 218.352 | 213.501 | +2.65% | True |
| stats-w2-d2-b10000-seed31 | all-cached | 218.554 | 189.030 | +13.54% | True |
| pivot-w1-d1-b10000-seed1 | in-place-compiler | 26.547 | 26.373 | -0.02% | True |
| pivot-w1-d1-b10000-seed1 | all | 26.453 | 26.434 | +0.44% | True |
| pivot-w1-d1-b10000-seed1 | cached | 26.582 | 26.412 | +0.63% | True |
| pivot-w1-d1-b10000-seed1 | all-cached | 26.722 | 26.409 | +1.08% | True |
| sand-damage-w1-d1-b10000-seed1 | in-place-compiler | 378.315 | 376.635 | +0.52% | True |
| sand-damage-w1-d1-b10000-seed1 | all | 377.095 | 376.423 | +0.58% | True |
| sand-damage-w1-d1-b10000-seed1 | cached | 377.122 | 365.565 | +3.29% | True |
| sand-damage-w1-d1-b10000-seed1 | all-cached | 377.466 | 364.857 | +3.25% | True |
| stats-w1-d2-exhaustive | workspace | 79.474 | 79.414 | +0.02% | True |
| stats-w1-d2-exhaustive | cached | 79.486 | 79.163 | +0.37% | True |
| stats-w2-d2-exhaustive | workspace | 152.148 | 152.306 | +0.04% | True |
| stats-w2-d2-exhaustive | cached | 152.278 | 151.750 | +0.56% | True |
| pivot-w1-d1-exhaustive | workspace | 24.860 | 24.810 | +0.22% | True |
| pivot-w1-d1-exhaustive | cached | 24.833 | 24.713 | +0.63% | True |
| sand-damage-w1-d1-exhaustive | workspace | 384.669 | 383.003 | +0.38% | True |
| sand-damage-w1-d1-exhaustive | cached | 384.337 | 372.409 | +2.97% | True |
