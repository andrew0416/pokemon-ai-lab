# S26c speed-only benchmark

One generic x86-64 release binary; serial execution pinned to one runner CPU. Seven ABBA/BAAB blocks; three selection seeds where applicable.
Intervals describe paired block variability on this runner, not variability between machines. Every candidate matches its reference tree, entire policy, certificate and work exactly.

| Case | Variant | Baseline ms | Candidate ms | Time reduction | Complete horizon |
|---|---|---:|---:|---:|---|
| stats-w1-d2-b4-seed1 | in-place | 14.374 | 13.869 | +3.64% | False |
| stats-w1-d2-b4-seed1 | workspace | 14.395 | 14.217 | +1.35% | False |
| stats-w1-d2-b4-seed1 | combined | 14.311 | 13.740 | +4.03% | False |
| stats-w1-d2-b10000-seed1 | in-place | 120.517 | 108.313 | +10.03% | True |
| stats-w1-d2-b10000-seed1 | workspace | 119.866 | 118.946 | +0.77% | True |
| stats-w1-d2-b10000-seed1 | combined | 119.328 | 106.919 | +10.40% | True |
| stats-w1-d2-b10000-seed7 | in-place | 120.610 | 108.097 | +10.23% | True |
| stats-w1-d2-b10000-seed7 | workspace | 119.612 | 118.815 | +0.91% | True |
| stats-w1-d2-b10000-seed7 | combined | 120.014 | 106.932 | +10.88% | True |
| stats-w1-d2-b10000-seed31 | in-place | 122.467 | 110.114 | +10.09% | True |
| stats-w1-d2-b10000-seed31 | workspace | 122.955 | 122.780 | +0.87% | True |
| stats-w1-d2-b10000-seed31 | combined | 122.370 | 109.166 | +11.06% | True |
| stats-w1-d2-exhaustive | workspace | 83.526 | 83.365 | +0.27% | True |
| stats-w2-d2-b4-seed1 | in-place | 27.917 | 27.109 | +3.25% | False |
| stats-w2-d2-b4-seed1 | workspace | 27.937 | 27.758 | +0.02% | False |
| stats-w2-d2-b4-seed1 | combined | 28.000 | 26.832 | +4.06% | False |
| stats-w2-d2-b10000-seed1 | in-place | 221.879 | 204.601 | +8.05% | True |
| stats-w2-d2-b10000-seed1 | workspace | 221.933 | 220.675 | +0.74% | True |
| stats-w2-d2-b10000-seed1 | combined | 223.078 | 203.127 | +8.80% | True |
| stats-w2-d2-b10000-seed7 | in-place | 226.430 | 209.490 | +7.81% | True |
| stats-w2-d2-b10000-seed7 | workspace | 227.267 | 226.184 | +0.43% | True |
| stats-w2-d2-b10000-seed7 | combined | 227.768 | 207.639 | +8.66% | True |
| stats-w2-d2-b10000-seed31 | in-place | 230.369 | 210.445 | +8.68% | True |
| stats-w2-d2-b10000-seed31 | workspace | 230.292 | 227.441 | +1.02% | True |
| stats-w2-d2-b10000-seed31 | combined | 228.769 | 208.483 | +8.94% | True |
| stats-w2-d2-exhaustive | workspace | 164.207 | 164.218 | +0.39% | True |
| pivot-w1-d1-b10000-seed1 | in-place | 27.402 | 27.338 | +0.55% | True |
| pivot-w1-d1-b10000-seed1 | workspace | 27.342 | 27.351 | +0.23% | True |
| pivot-w1-d1-b10000-seed1 | combined | 27.379 | 27.274 | +0.54% | True |
| pivot-w1-d1-exhaustive | workspace | 25.530 | 25.414 | +0.42% | True |
| sand-damage-w1-d1-b10000-seed1 | in-place | 383.013 | 381.434 | -0.16% | True |
| sand-damage-w1-d1-b10000-seed1 | workspace | 378.884 | 379.329 | -0.08% | True |
| sand-damage-w1-d1-b10000-seed1 | combined | 380.854 | 380.871 | -0.26% | True |
| sand-damage-w1-d1-exhaustive | workspace | 380.965 | 380.923 | -0.37% | True |
