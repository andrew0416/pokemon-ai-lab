# S26e shared-final-passes speed-only benchmark

One generic x86-64 release binary; serial execution pinned to one runner CPU. Nine ABBA/BAAB blocks; fixed identical selection seed.
Intervals describe paired block variability on this runner, not variability between machines. Same-work pairs preserve all counters; finite-game pairs preserve the entire canonical tree and policy but growing performs intermediate solves.

| Case | Variant | Baseline ms | Candidate ms | Time reduction | Complete horizon |
|---|---|---:|---:|---:|---|
| stats-w1-d2-shared-growing | shared | 52.922 | 52.354 | +1.89% | True |
| stats-w2-d2-shared-growing | shared | 97.377 | 96.796 | +0.10% | True |
| pivot-w1-d1-shared-growing | shared | 12.936 | 12.896 | -1.43% | True |
| sand-damage-w1-d1-shared-growing | shared | 179.675 | 180.367 | -0.31% | True |
| stats-w4-d2-shared-growing | shared | 188.425 | 189.968 | -0.57% | True |
| narrow-w1-d3-shared-growing | shared | 36.040 | 35.569 | +0.50% | True |
