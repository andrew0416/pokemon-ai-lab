# S26c speed-only benchmark

One generic x86-64 release binary; serial execution pinned to one runner CPU. Seven ABBA/BAAB blocks; three selection seeds where applicable.
Intervals describe paired block variability on this runner, not variability between machines. Same-work pairs preserve all counters; finite-game pairs preserve the entire canonical tree and policy but growing performs intermediate solves.

| Case | Variant | Baseline ms | Candidate ms | Time reduction | Complete horizon |
|---|---|---:|---:|---:|---|
| stats-w1-d2-same-work-seed1 | all-cached | 120.237 | 101.374 | +15.72% | True |
| stats-w1-d2-same-work-seed7 | all-cached | 121.150 | 101.834 | +16.14% | True |
| stats-w1-d2-same-work-seed31 | all-cached | 122.094 | 103.700 | +15.28% | True |
| stats-w1-d2-vs-exhaustive | growing | 82.644 | 121.603 | -46.84% | True |
| stats-w1-d2-vs-exhaustive | all-cached | 82.627 | 102.593 | -23.89% | True |
| stats-w2-d2-same-work-seed1 | all-cached | 224.320 | 191.040 | +14.75% | True |
| stats-w2-d2-same-work-seed7 | all-cached | 233.952 | 195.247 | +16.11% | True |
| stats-w2-d2-same-work-seed31 | all-cached | 230.786 | 196.507 | +15.11% | True |
| stats-w2-d2-vs-exhaustive | growing | 162.474 | 226.287 | -39.36% | True |
| stats-w2-d2-vs-exhaustive | all-cached | 162.701 | 192.746 | -18.50% | True |
| pivot-w1-d1-same-work-seed1 | all-cached | 27.144 | 26.858 | +0.94% | True |
| pivot-w1-d1-vs-exhaustive | growing | 25.245 | 27.043 | -6.69% | True |
| pivot-w1-d1-vs-exhaustive | all-cached | 25.275 | 26.604 | -5.30% | True |
| sand-damage-w1-d1-same-work-seed1 | all-cached | 377.328 | 363.772 | +3.63% | True |
| sand-damage-w1-d1-vs-exhaustive | growing | 371.466 | 375.789 | -1.05% | True |
| sand-damage-w1-d1-vs-exhaustive | all-cached | 371.963 | 363.497 | +2.11% | True |
| stats-w4-d2-same-work-seed1 | all-cached | 474.419 | 390.291 | +17.69% | True |
| stats-w4-d2-vs-exhaustive | growing | 320.673 | 467.257 | -45.82% | True |
| stats-w4-d2-vs-exhaustive | all-cached | 320.355 | 387.214 | -20.75% | True |
| narrow-w1-d3-same-work-seed1 | all-cached | 91.831 | 70.234 | +23.09% | True |
| narrow-w1-d3-vs-exhaustive | growing | 48.779 | 90.047 | -82.48% | True |
| narrow-w1-d3-vs-exhaustive | all-cached | 48.571 | 69.716 | -43.90% | True |
