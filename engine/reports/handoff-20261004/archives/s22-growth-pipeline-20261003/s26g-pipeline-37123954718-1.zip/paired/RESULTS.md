# S26g growth pipeline speed-only benchmark

One generic x86-64 release binary; serial baseline and bounded Rayon pools share up to four permitted runner CPUs. Nine ABBA/BAAB blocks; fixed identical selection seed.
Intervals describe paired block variability on this runner, not variability between machines. Same finite game and same gap threshold; policies and iteration counts may differ. Nonconverged pairs are censored. Fixed-tree timings exclude engine construction, growing timings include it.

| Case | Variant | Baseline ms | Candidate ms | Time reduction | Complete horizon |
|---|---|---:|---:|---:|---|
| stats-w1-d2-growing-1-index | frontier-index | 75.607 | 74.196 | +0.80% | True |
| stats-w1-d2-growing-1-index | disabled-control | 74.538 | 73.121 | +0.06% | True |
| stats-w1-d2-growing-2-owned | owned-compiler | 74.410 | 72.598 | +0.56% | True |
| stats-w1-d2-growing-3-delta | delta-kernel | 73.227 | 73.622 | -0.44% | True |
| stats-w1-d2-growing-4-checks | compressed-checks | 74.054 | 74.350 | -0.27% | True |
| stats-w1-d2-growing-all | all-four | 72.897 | 73.226 | +1.12% | True |
| stats-w2-d2-growing-1-index | frontier-index | 141.670 | 141.123 | +0.57% | True |
| stats-w2-d2-growing-1-index | disabled-control | 142.726 | 141.193 | +0.67% | True |
| stats-w2-d2-growing-2-owned | owned-compiler | 143.224 | 140.742 | +0.96% | True |
| stats-w2-d2-growing-3-delta | delta-kernel | 142.429 | 141.117 | +0.43% | True |
| stats-w2-d2-growing-4-checks | compressed-checks | 139.369 | 141.667 | -1.42% | True |
| stats-w2-d2-growing-all | all-four | 140.520 | 140.388 | +0.09% | True |
| pivot-w1-d1-growing-1-index | frontier-index | 23.365 | 23.293 | +0.18% | True |
| pivot-w1-d1-growing-1-index | disabled-control | 23.355 | 23.322 | +0.18% | True |
| pivot-w1-d1-growing-2-owned | owned-compiler | 23.267 | 23.424 | -0.22% | True |
| pivot-w1-d1-growing-3-delta | delta-kernel | 24.503 | 24.521 | -0.03% | True |
| pivot-w1-d1-growing-4-checks | compressed-checks | 24.482 | 24.433 | +0.11% | True |
| pivot-w1-d1-growing-all | all-four | 24.408 | 24.356 | +0.21% | True |
| sand-damage-w1-d1-growing-1-index | frontier-index | 264.888 | 269.031 | -0.35% | True |
| sand-damage-w1-d1-growing-1-index | disabled-control | 268.769 | 267.755 | -0.59% | True |
| sand-damage-w1-d1-growing-2-owned | owned-compiler | 269.726 | 268.173 | +0.58% | True |
| sand-damage-w1-d1-growing-3-delta | delta-kernel | 271.402 | 271.982 | -0.21% | True |
| sand-damage-w1-d1-growing-4-checks | compressed-checks | 285.515 | 283.234 | +0.63% | True |
| sand-damage-w1-d1-growing-all | all-four | 267.967 | 269.189 | -0.33% | True |
| stats-w4-d2-growing-1-index | frontier-index | 280.125 | 279.881 | +0.20% | True |
| stats-w4-d2-growing-1-index | disabled-control | 279.473 | 280.350 | -0.12% | True |
| stats-w4-d2-growing-2-owned | owned-compiler | 282.900 | 281.351 | +0.40% | True |
| stats-w4-d2-growing-3-delta | delta-kernel | 276.264 | 279.198 | -1.38% | True |
| stats-w4-d2-growing-4-checks | compressed-checks | 279.337 | 280.008 | +0.10% | True |
| stats-w4-d2-growing-all | all-four | 279.766 | 278.259 | +0.09% | True |
| narrow-w1-d3-growing-1-index | frontier-index | 45.439 | 45.560 | +0.41% | True |
| narrow-w1-d3-growing-1-index | disabled-control | 45.406 | 45.522 | -0.25% | True |
| narrow-w1-d3-growing-2-owned | owned-compiler | 46.031 | 45.173 | -0.04% | True |
| narrow-w1-d3-growing-3-delta | delta-kernel | 45.567 | 45.303 | +0.38% | True |
| narrow-w1-d3-growing-4-checks | compressed-checks | 46.224 | 46.092 | +1.05% | True |
| narrow-w1-d3-growing-all | all-four | 46.074 | 45.787 | +0.44% | True |
