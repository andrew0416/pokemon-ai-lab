# S26c speed-only benchmark

One generic x86-64 release binary; serial execution pinned to one runner CPU. Seven ABBA/BAAB blocks; three selection seeds where applicable.
Intervals describe paired block variability on this runner, not variability between machines. Same-work pairs preserve all counters; finite-game pairs preserve the entire canonical tree and policy but growing performs intermediate solves.

| Case | Variant | Baseline ms | Candidate ms | Time reduction | Complete horizon |
|---|---|---:|---:|---:|---|
| stats-w1-d2-same-work-seed1 | writer | 121.022 | 116.324 | +5.52% | True |
| stats-w1-d2-same-work-seed1 | all-cached | 121.970 | 102.247 | +16.30% | True |
| stats-w1-d2-same-work-seed1 | all-writer | 118.860 | 96.732 | +19.24% | True |
| stats-w1-d2-vs-exhaustive | exhaustive-writing | 83.919 | 77.404 | +7.85% | True |
| stats-w1-d2-vs-exhaustive | all-writer | 83.723 | 97.839 | -16.85% | True |
| stats-w2-d2-same-work-seed1 | writer | 232.485 | 217.800 | +4.58% | True |
| stats-w2-d2-same-work-seed1 | all-cached | 230.329 | 192.710 | +16.00% | True |
| stats-w2-d2-same-work-seed1 | all-writer | 229.897 | 181.130 | +21.19% | True |
| stats-w2-d2-vs-exhaustive | exhaustive-writing | 162.410 | 150.277 | +7.45% | True |
| stats-w2-d2-vs-exhaustive | all-writer | 162.241 | 182.004 | -12.37% | True |
| pivot-w1-d1-same-work-seed1 | writer | 27.247 | 24.706 | +9.40% | True |
| pivot-w1-d1-same-work-seed1 | all-cached | 27.261 | 26.916 | +1.47% | True |
| pivot-w1-d1-same-work-seed1 | all-writer | 27.280 | 24.415 | +10.41% | True |
| pivot-w1-d1-vs-exhaustive | exhaustive-writing | 25.546 | 22.927 | +10.03% | True |
| pivot-w1-d1-vs-exhaustive | all-writer | 25.560 | 24.763 | +3.27% | True |
| sand-damage-w1-d1-same-work-seed1 | writer | 386.022 | 346.302 | +10.43% | True |
| sand-damage-w1-d1-same-work-seed1 | all-cached | 382.420 | 372.409 | +3.26% | True |
| sand-damage-w1-d1-same-work-seed1 | all-writer | 383.945 | 331.769 | +13.16% | True |
| sand-damage-w1-d1-vs-exhaustive | exhaustive-writing | 375.045 | 325.093 | +13.32% | True |
| sand-damage-w1-d1-vs-exhaustive | all-writer | 373.899 | 325.675 | +12.45% | True |
| stats-w4-d2-same-work-seed1 | writer | 462.078 | 439.625 | +4.99% | True |
| stats-w4-d2-same-work-seed1 | all-cached | 460.093 | 385.323 | +16.45% | True |
| stats-w4-d2-same-work-seed1 | all-writer | 460.710 | 361.255 | +21.68% | True |
| stats-w4-d2-vs-exhaustive | exhaustive-writing | 330.638 | 304.019 | +8.01% | True |
| stats-w4-d2-vs-exhaustive | all-writer | 330.172 | 370.392 | -12.18% | True |
| narrow-w1-d3-same-work-seed1 | writer | 87.598 | 84.106 | +4.11% | True |
| narrow-w1-d3-same-work-seed1 | all-cached | 87.337 | 68.928 | +21.05% | True |
| narrow-w1-d3-same-work-seed1 | all-writer | 86.734 | 65.833 | +24.48% | True |
| narrow-w1-d3-vs-exhaustive | exhaustive-writing | 48.123 | 44.539 | +7.54% | True |
| narrow-w1-d3-vs-exhaustive | all-writer | 48.129 | 65.369 | -35.54% | True |
