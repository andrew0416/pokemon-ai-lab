# S26e owned-transition speed-only benchmark

One generic x86-64 release binary; serial execution pinned to one runner CPU. Nine ABBA/BAAB blocks; fixed identical selection seed.
Intervals describe paired block variability on this runner, not variability between machines. Same-work pairs preserve all counters; finite-game pairs preserve the entire canonical tree and policy but growing performs intermediate solves.

| Case | Variant | Baseline ms | Candidate ms | Time reduction | Complete horizon |
|---|---|---:|---:|---:|---|
| stats-w1-d2-owned-growing | owned | 95.624 | 93.591 | +2.13% | True |
| stats-w1-d2-owned-exhaustive | owned | 73.846 | 72.074 | +2.42% | True |
| stats-w2-d2-owned-growing | owned | 181.724 | 175.770 | +3.07% | True |
| stats-w2-d2-owned-exhaustive | owned | 143.081 | 138.766 | +3.00% | True |
| pivot-w1-d1-owned-growing | owned | 24.611 | 24.198 | +1.70% | True |
| pivot-w1-d1-owned-exhaustive | owned | 22.323 | 22.006 | +1.48% | True |
| sand-damage-w1-d1-owned-growing | owned | 349.211 | 332.489 | +4.47% | True |
| sand-damage-w1-d1-owned-exhaustive | owned | 337.834 | 323.724 | +3.47% | True |
| stats-w4-d2-owned-growing | owned | 365.206 | 355.722 | +2.62% | True |
| stats-w4-d2-owned-exhaustive | owned | 289.100 | 281.464 | +2.64% | True |
| narrow-w1-d3-owned-growing | owned | 69.444 | 68.484 | +1.60% | True |
| narrow-w1-d3-owned-exhaustive | owned | 44.941 | 43.990 | +2.27% | True |
