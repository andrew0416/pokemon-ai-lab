# S26c speed-only benchmark

One generic x86-64 release binary; serial execution pinned to one runner CPU. Seven ABBA/BAAB blocks; three selection seeds where applicable.
Intervals describe paired block variability on this runner, not variability between machines. Every candidate matches its reference tree, entire policy, certificate and work exactly.

| Case | Variant | Baseline ms | Candidate ms | Time reduction | Complete horizon |
|---|---|---:|---:|---:|---|
| stats-w1-d2-b4-seed1 | in-place | 9.389 | 8.869 | +5.68% | False |
| stats-w1-d2-b4-seed1 | compiler | 9.377 | 9.315 | +0.89% | False |
| stats-w1-d2-b4-seed1 | in-place-compiler | 9.400 | 8.789 | +6.40% | False |
| stats-w1-d2-b4-seed1 | all | 9.400 | 8.717 | +6.93% | False |
| stats-w1-d2-b10000-seed1 | in-place | 85.193 | 77.295 | +13.72% | True |
| stats-w1-d2-b10000-seed1 | compiler | 84.775 | 82.268 | +2.96% | True |
| stats-w1-d2-b10000-seed1 | in-place-compiler | 85.040 | 78.592 | +15.48% | True |
| stats-w1-d2-b10000-seed1 | all | 85.236 | 75.792 | +15.48% | True |
| stats-w1-d2-b10000-seed7 | in-place | 83.675 | 72.498 | +13.36% | True |
| stats-w1-d2-b10000-seed7 | compiler | 83.439 | 80.175 | +3.77% | True |
| stats-w1-d2-b10000-seed7 | in-place-compiler | 84.347 | 70.688 | +15.23% | True |
| stats-w1-d2-b10000-seed7 | all | 84.444 | 69.876 | +17.34% | True |
| stats-w1-d2-b10000-seed31 | in-place | 85.723 | 74.244 | +13.31% | True |
| stats-w1-d2-b10000-seed31 | compiler | 84.189 | 80.616 | +4.02% | True |
| stats-w1-d2-b10000-seed31 | in-place-compiler | 85.925 | 71.954 | +15.10% | True |
| stats-w1-d2-b10000-seed31 | all | 85.922 | 71.478 | +15.78% | True |
| stats-w2-d2-b4-seed1 | in-place | 18.092 | 17.245 | +4.62% | False |
| stats-w2-d2-b4-seed1 | compiler | 17.964 | 17.803 | +0.80% | False |
| stats-w2-d2-b4-seed1 | in-place-compiler | 18.028 | 17.053 | +5.24% | False |
| stats-w2-d2-b4-seed1 | all | 18.071 | 16.943 | +6.37% | False |
| stats-w2-d2-b10000-seed1 | in-place | 149.977 | 134.256 | +10.41% | True |
| stats-w2-d2-b10000-seed1 | compiler | 151.005 | 139.755 | +6.56% | True |
| stats-w2-d2-b10000-seed1 | in-place-compiler | 149.892 | 130.768 | +13.68% | True |
| stats-w2-d2-b10000-seed1 | all | 150.970 | 128.509 | +15.20% | True |
| stats-w2-d2-b10000-seed7 | in-place | 154.540 | 139.122 | +10.24% | True |
| stats-w2-d2-b10000-seed7 | compiler | 154.801 | 145.832 | +5.68% | True |
| stats-w2-d2-b10000-seed7 | in-place-compiler | 153.054 | 132.630 | +13.81% | True |
| stats-w2-d2-b10000-seed7 | all | 153.284 | 130.099 | +14.88% | True |
| stats-w2-d2-b10000-seed31 | in-place | 153.991 | 137.432 | +10.78% | True |
| stats-w2-d2-b10000-seed31 | compiler | 155.019 | 147.016 | +4.81% | True |
| stats-w2-d2-b10000-seed31 | in-place-compiler | 154.555 | 132.688 | +13.96% | True |
| stats-w2-d2-b10000-seed31 | all | 153.748 | 130.889 | +14.68% | True |
| pivot-w1-d1-b10000-seed1 | in-place | 18.243 | 18.298 | -0.38% | True |
| pivot-w1-d1-b10000-seed1 | compiler | 18.235 | 18.115 | +0.62% | True |
| pivot-w1-d1-b10000-seed1 | in-place-compiler | 18.222 | 18.111 | +0.63% | True |
| pivot-w1-d1-b10000-seed1 | all | 18.250 | 18.145 | +0.67% | True |
| sand-damage-w1-d1-b10000-seed1 | in-place | 256.401 | 256.312 | -0.21% | True |
| sand-damage-w1-d1-b10000-seed1 | compiler | 257.359 | 257.527 | +0.01% | True |
| sand-damage-w1-d1-b10000-seed1 | in-place-compiler | 258.172 | 259.621 | -0.31% | True |
| sand-damage-w1-d1-b10000-seed1 | all | 258.050 | 257.660 | +0.45% | True |
