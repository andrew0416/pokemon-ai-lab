# S26e parallel-transitions speed-only benchmark

One generic x86-64 release binary; serial baseline and bounded Rayon pools share up to four permitted runner CPUs. Nine ABBA/BAAB blocks; fixed identical selection seed.
Intervals describe paired block variability on this runner, not variability between machines. Same-work pairs preserve all counters; finite-game pairs preserve the entire canonical tree and policy but growing performs intermediate solves.

| Case | Variant | Baseline ms | Candidate ms | Time reduction | Complete horizon |
|---|---|---:|---:|---:|---|
| stats-w1-d2-parallel-growing | parallel-1 | 89.074 | 88.953 | +0.07% | True |
| stats-w1-d2-parallel-growing | parallel-2 | 89.385 | 108.659 | -21.70% | True |
| stats-w1-d2-parallel-growing | parallel-4 | 89.014 | 84.197 | +5.41% | True |
| stats-w2-d2-parallel-growing | parallel-1 | 167.976 | 168.878 | -0.53% | True |
| stats-w2-d2-parallel-growing | parallel-2 | 168.826 | 208.775 | -22.48% | True |
| stats-w2-d2-parallel-growing | parallel-4 | 169.114 | 159.109 | +6.16% | True |
| pivot-w1-d1-parallel-growing | parallel-1 | 25.172 | 24.947 | +0.28% | True |
| pivot-w1-d1-parallel-growing | parallel-2 | 25.001 | 38.038 | -51.76% | True |
| pivot-w1-d1-parallel-growing | parallel-4 | 24.967 | 39.624 | -57.20% | True |
| sand-damage-w1-d1-parallel-growing | parallel-1 | 318.266 | 318.454 | -0.17% | True |
| sand-damage-w1-d1-parallel-growing | parallel-2 | 317.809 | 284.876 | +10.45% | True |
| sand-damage-w1-d1-parallel-growing | parallel-4 | 317.573 | 276.281 | +13.00% | True |
| stats-w4-d2-parallel-growing | parallel-1 | 337.585 | 338.146 | -0.27% | True |
| stats-w4-d2-parallel-growing | parallel-2 | 337.723 | 410.419 | -21.53% | True |
| stats-w4-d2-parallel-growing | parallel-4 | 337.869 | 319.938 | +5.28% | True |
| narrow-w1-d3-parallel-growing | parallel-1 | 58.979 | 58.563 | +0.31% | True |
| narrow-w1-d3-parallel-growing | parallel-2 | 59.105 | 69.141 | -17.28% | True |
| narrow-w1-d3-parallel-growing | parallel-4 | 59.069 | 57.350 | +3.22% | True |
