# S26e interned history speed-only benchmark

One generic x86-64 release binary; serial execution pinned to one runner CPU. Nine ABBA/BAAB blocks; fixed identical selection seed.
Intervals describe paired block variability on this runner, not variability between machines. All pairs preserve the complete tree, policy, diagnostics and work counters; only builder history storage changes.

| Case | Variant | Baseline ms | Candidate ms | Time reduction | Complete horizon |
|---|---|---:|---:|---:|---|
| stats-w1-d2-history-growing | interned | 93.748 | 92.889 | +0.73% | True |
| stats-w1-d2-history-exhaustive | interned | 69.729 | 68.739 | +1.43% | True |
| stats-w2-d2-history-growing | interned | 171.119 | 165.062 | +3.49% | True |
| stats-w2-d2-history-exhaustive | interned | 133.790 | 127.858 | +4.43% | True |
| pivot-w1-d1-history-growing | interned | 23.526 | 22.646 | +3.38% | True |
| pivot-w1-d1-history-exhaustive | interned | 21.446 | 21.720 | -1.54% | True |
| sand-damage-w1-d1-history-growing | interned | 300.940 | 308.390 | -2.42% | True |
| sand-damage-w1-d1-history-exhaustive | interned | 300.245 | 302.569 | -0.82% | True |
| stats-w4-d2-history-growing | interned | 338.968 | 322.152 | +4.94% | True |
| stats-w4-d2-history-exhaustive | interned | 264.476 | 247.894 | +6.29% | True |
| narrow-w1-d3-history-growing | interned | 68.333 | 66.682 | +2.37% | True |
| narrow-w1-d3-history-exhaustive | interned | 41.874 | 40.879 | +2.30% | True |
