# S26c speed-only benchmark

One generic x86-64 release binary; serial execution pinned to one runner CPU. Seven ABBA/BAAB blocks; three selection seeds where applicable.
Intervals describe paired block variability on this runner, not variability between machines. Partial trees perform less work and are not equivalent full-depth computations.

| Case | Variant | Baseline ms | Candidate ms | Time reduction | Complete horizon |
|---|---|---:|---:|---:|---|
| stats-w1-d2 | b2-seed1 | 83.331 | 5.457 | +93.44% | False |
| stats-w1-d2 | b2-seed7 | 83.146 | 5.454 | +93.44% | False |
| stats-w1-d2 | b2-seed31 | 83.121 | 5.457 | +93.44% | False |
| stats-w1-d2 | b8-seed1 | 82.870 | 48.502 | +41.63% | False |
| stats-w1-d2 | b8-seed7 | 83.000 | 54.537 | +34.28% | False |
| stats-w1-d2 | b8-seed31 | 83.274 | 48.195 | +42.03% | False |
| stats-w1-d2 | full-seed1 | 83.392 | 115.836 | -39.12% | True |
| stats-w1-d2 | full-seed7 | 83.213 | 116.324 | -39.45% | True |
| stats-w1-d2 | full-seed31 | 83.531 | 119.712 | -43.41% | True |
| stats-w2-d2 | b1-seed1 | 162.579 | 5.127 | +96.85% | False |
| stats-w2-d2 | b1-seed7 | 162.577 | 5.111 | +96.85% | False |
| stats-w2-d2 | b1-seed31 | 162.959 | 5.192 | +96.82% | False |
| stats-w2-d2 | b2-seed1 | 162.667 | 10.756 | +93.38% | False |
| stats-w2-d2 | b2-seed7 | 162.647 | 10.762 | +93.37% | False |
| stats-w2-d2 | b2-seed31 | 162.804 | 10.748 | +93.39% | False |
| stats-w2-d2 | b4-seed1 | 162.711 | 28.356 | +82.61% | False |
| stats-w2-d2 | b4-seed7 | 162.946 | 28.279 | +82.68% | False |
| stats-w2-d2 | b4-seed31 | 162.480 | 27.577 | +83.01% | False |
| stats-w2-d2 | b8-seed1 | 162.602 | 91.346 | +43.77% | False |
| stats-w2-d2 | b8-seed7 | 163.196 | 105.641 | +35.27% | False |
| stats-w2-d2 | b8-seed31 | 162.863 | 92.910 | +42.78% | False |
| stats-w2-d2 | full-seed1 | 163.373 | 220.773 | -35.11% | True |
| stats-w2-d2 | full-seed7 | 162.728 | 224.762 | -38.15% | True |
| stats-w2-d2 | full-seed31 | 163.007 | 224.764 | -38.13% | True |
| pivot-w1-d1 | full-seed1 | 25.602 | 27.156 | -5.78% | True |
| sand-damage-w1-d1 | full-seed1 | 366.872 | 372.873 | -1.98% | True |
