# S26e growth-cadence speed-only benchmark

One generic x86-64 release binary; serial baseline and bounded Rayon pools share up to four permitted runner CPUs. Nine ABBA/BAAB blocks; fixed identical selection seed.
Intervals describe paired block variability on this runner, not variability between machines. Same-work pairs preserve all counters; finite-game pairs preserve the entire canonical tree and policy but growing performs intermediate solves.

| Case | Variant | Baseline ms | Candidate ms | Time reduction | Complete horizon |
|---|---|---:|---:|---:|---|
| stats-w1-d2-cadence-growing | cadence-1 | 44.597 | 44.242 | +0.28% | True |
| stats-w1-d2-cadence-growing | cadence-2 | 43.697 | 40.261 | +6.96% | True |
| stats-w1-d2-cadence-growing | cadence-4 | 44.123 | 38.763 | +12.04% | True |
| stats-w2-d2-cadence-growing | cadence-1 | 81.224 | 82.332 | -1.60% | True |
| stats-w2-d2-cadence-growing | cadence-2 | 83.511 | 78.677 | +6.03% | True |
| stats-w2-d2-cadence-growing | cadence-4 | 82.755 | 74.479 | +9.10% | True |
| pivot-w1-d1-cadence-growing | cadence-1 | 13.629 | 13.653 | +0.29% | True |
| pivot-w1-d1-cadence-growing | cadence-2 | 13.416 | 13.373 | +0.33% | True |
| pivot-w1-d1-cadence-growing | cadence-4 | 13.459 | 13.459 | +0.59% | True |
| sand-damage-w1-d1-cadence-growing | cadence-1 | 166.456 | 168.604 | -1.29% | True |
| sand-damage-w1-d1-cadence-growing | cadence-2 | 168.469 | 169.222 | +0.16% | True |
| sand-damage-w1-d1-cadence-growing | cadence-4 | 167.217 | 167.581 | +0.60% | True |
| stats-w4-d2-cadence-growing | cadence-1 | 162.959 | 163.039 | -0.63% | True |
| stats-w4-d2-cadence-growing | cadence-2 | 171.425 | 152.806 | +10.57% | True |
| stats-w4-d2-cadence-growing | cadence-4 | 165.152 | 142.209 | +13.89% | True |
| narrow-w1-d3-cadence-growing | cadence-1 | 30.303 | 29.898 | -0.53% | True |
| narrow-w1-d3-cadence-growing | cadence-2 | 30.345 | 26.721 | +12.33% | True |
| narrow-w1-d3-cadence-growing | cadence-4 | 29.623 | 23.744 | +19.05% | True |
