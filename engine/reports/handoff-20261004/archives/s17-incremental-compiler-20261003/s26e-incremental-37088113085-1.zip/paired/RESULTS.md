# S26e incremental-compilation speed-only benchmark

One generic x86-64 release binary; serial execution pinned to one runner CPU. Nine ABBA/BAAB blocks; fixed identical selection seed.
Intervals describe paired block variability on this runner, not variability between machines. Same-work pairs preserve all counters; finite-game pairs preserve the entire canonical tree and policy but growing performs intermediate solves.

| Case | Variant | Baseline ms | Candidate ms | Time reduction | Complete horizon |
|---|---|---:|---:|---:|---|
| stats-w1-d2-incremental-growing | incremental | 97.500 | 93.495 | +4.11% | True |
| stats-w2-d2-incremental-growing | incremental | 180.284 | 172.566 | +4.27% | True |
| pivot-w1-d1-incremental-growing | incremental | 24.497 | 24.933 | -1.34% | True |
| sand-damage-w1-d1-incremental-growing | incremental | 316.537 | 315.087 | +0.29% | True |
| stats-w4-d2-incremental-growing | incremental | 360.291 | 343.051 | +4.56% | True |
| narrow-w1-d3-incremental-growing | incremental | 67.765 | 61.284 | +9.41% | True |
